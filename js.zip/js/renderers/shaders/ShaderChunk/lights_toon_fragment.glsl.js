export default /* glsl */`
ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;
`;
