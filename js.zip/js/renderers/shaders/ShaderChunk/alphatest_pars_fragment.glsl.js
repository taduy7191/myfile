export default /* glsl */`
#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif
`;
