export default /* glsl */`
#ifdef USE_FOG

	varying float vFogDepth;

#endif
`;
